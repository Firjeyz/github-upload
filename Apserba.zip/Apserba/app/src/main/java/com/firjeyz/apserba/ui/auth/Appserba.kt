package com.firjeyz.apserba.ui.auth

import android.content.Context
import com.firjeyz.apserba.data.model.ActionState
import com.firjeyz.apserba.data.repository.AuthRepository
import kotlinx.coroutines.*

object Appserba {
    fun logout(context: Context,callback:((ActionState<Boolean>)->Unit)?=null){
        val repo = AuthRepository(context)
        CoroutineScope(Dispatchers.IO).launch {
            val resp = repo.logout()
            withContext(Dispatchers.Main){
                if (callback !=null) callback.invoke(resp)
            }
        }
    }
}